var $ = function(id) { return document.getElementById(id); };

window.onload = function() {
    document.getElementById("update").onclick = function(){showMax()};
};

showMax = function () {

}
