﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_3
{
    public partial class Catering : Form
    {
        public Catering()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //declare and initialize variables
            int cost = 0;
            String name, number, guests, entree, side, dessert = "";

            name = textBox1.Text;
            number = textBox2.Text;
            guests = textBox3.Text;

            int guestNum;
            bool isNumerical = int.TryParse(guests, out guestNum);

            //check if guest is numerical
            if (isNumerical)
            {
                cost = guestNum * 35;
            }
            else
            {
                cost = 0;
                MessageBox.Show("Guest number entered was not numeric.");
            }

            //assign entree
            if(checkBox1.Checked)
            {
                entree = "Chicken";
            }
            else if(checkBox2.Checked)
            {
                entree = "Steak";
            }
            else if(checkBox3.Checked)
            {
                entree = "Spaghetti";
            }
            else if(checkBox4.Checked)
            {
                entree = "Soup";
            }
            else
            {
                entree = "none";
            }

            //assign sides
            int sideAmount = 0;
            side = "";
            if(checkBox5.Checked)
            {
                side += "Fries ";
                sideAmount++;
            }
            else if(checkBox6.Checked)
            {
                side += "Beans ";
                sideAmount++;
            }
            else if(checkBox7.Checked)
            {
                side += "Fruit ";
                sideAmount++;
            }
            else if(checkBox8.Checked)
            {
                side += "Bread ";
                sideAmount++;
            }
            else
            {
                side = "none";
            }

            if(checkBox9.Checked)
            {
                dessert = "Cake";
            }
            else if(checkBox10.Checked)
            {
                dessert = "Ice Cream";
            }
            else if(checkBox11.Checked)
            {
                dessert = "Pie";
            }
            else
            {
                dessert = "none";
            }

            if(sideAmount > 2)
            { 
                checkBox5.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox8.Checked = false;
                MessageBox.Show("Only two side dishes are allowed.");
            }
            else
            {
                TextWriter writer = new StreamWriter("Event.txt");
                writer.Write(name + " " + number + " " + guests + " " + entree + " " + side + " " + dessert + " " + cost);
                writer.Close();

                MessageBox.Show("Thank you for your order!");
            }
        }
    }
}
