﻿using System;

public class Car
{
    public int year_model { get; set; }
    public string make { get; set; }
    public int speed { get; set; }

    public void CarValues(string inMake, int inModel)
    {
        make = inMake;
        year_model = inModel;
        speed = 0;
    }

    public int Accelerate()
    {
        return speed += 5;
    }

    public int Brake()
    {
        return speed -= 5;
    }

    public int current_speed()
    {
        Console.WriteLine("Car's current Speed: " + speed);
        return speed;
    }
}