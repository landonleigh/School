﻿using System;

public class Main
{
    static void Main(string[] args)
    {
        Car car = new Car();
        String make = "";
        int year = 0;

        Console.WriteLine("Enter make of car: ");
        make = Console.ReadLine();

        Console.WriteLine("Enter year of car: ");
        year = Console.ReadLine();

        car.CarValues(make, year);

        Console.WriteLine("Accelerating");
        car.Accelerate();
        Console.WriteLine(car.current_speed());
        car.Accelerate();
        Console.WriteLine(car.current_speed());
        car.Accelerate();
        Console.WriteLine(car.current_speed());
        car.Accelerate();
        Console.WriteLine(car.current_speed());
        car.Accelerate();
        Console.WriteLine(car.current_speed());

        Console.WriteLine("Breaking");
        car.Brake();
        Console.WriteLine(car.current_speed());
        car.Brake();
        Console.WriteLine(car.current_speed());
        car.Brake();
        Console.WriteLine(car.current_speed());
        car.Brake();
        Console.WriteLine(car.current_speed());
        car.Brake();
        Console.WriteLine(car.current_speed());

    }
}
