﻿using System;
using System.IO;

namespace File_InputOutput
{
    //Landon Leigh

    public class InputOutput_Activity
    {
        public static void Main()
        {
            //Create variables to read in values from text file
            FileStream inFile = new FileStream("Numbers.txt", FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            //Create variables to write to text files
            StreamWriter even = new StreamWriter("Even.txt");
            StreamWriter odd = new StreamWriter("Odd.txt");

            //Create variables to keep track of values
            string recordIn;
            recordIn = reader.ReadLine();
            string recordOut;
            int num;

            //Loop through file to read numbers
            while (recordIn != null)
            {
                //record numbers and parse to int
                recordOut = recordIn;
                num = int.Parse(recordIn);

                //check if number is even or odd and write to correct file
                if (num % 2 == 0)
                {
                    even.WriteLine(recordOut);
                }
                else if (num % 2 != 0)
                {
                    odd.WriteLine(recordOut);
                }
                recordIn = reader.ReadLine();
            }

            reader.Close();
            even.Close();
            odd.Close();
        }
    }
}
